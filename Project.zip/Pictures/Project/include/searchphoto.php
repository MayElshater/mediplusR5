<div class="tm-hero d-flex justify-content-center align-items-center" data-parallax="scroll" data-image-src="img/hero.jpg">
        <form class="d-flex tm-search-form" action="search.php" method="post">
          <input class="form-control" type="text" placeholder="Search" aria-label="Search" name="query">
              <button class="btn btn-outline-success tm-search-btn" type="submit">
                <i class="fas fa-search"></i>
              </button>
       </form>

    </div>