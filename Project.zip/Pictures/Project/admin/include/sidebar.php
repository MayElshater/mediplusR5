<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
						<div class="menu_section">
							<h3>General</h3>
							<ul class="nav side-menu">
								<li><a><i class="fa fa-users"></i> Users <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">
										<li><a href="users.php">Users List</a></li>
										<li><a href="addUser.php">Add User</a></li>
									</ul>
								</li>
								<li><a><i class="fa fa-edit"></i> Tags <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">
									    <li><a href="categories.php">Tags List</a></li>
										<li><a href="addCategory.php">Add Tag</a></li>	
									</ul>
								</li>
								<li><a><i class="fa fa-desktop"></i> Photos <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">
										<li><a href="addPhoto.php">Add Photo</a></li>
										<li><a href="photos.php">Photos List</a></li>
									</ul>
								</li>
							<li><a><i class="fa fa-calendar-o"></i> Meetings <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">
									    <li><a href="meetings.php">meeting List</a></li>
										<li><a href="addMeeting.php">Add Meeting</a></li>
									</ul>
								</li>
							</ul>
						</div>

					</div>
					