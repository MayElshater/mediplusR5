
<div class="profile clearfix">
  <div class="profile_pic">
    <img src="images/<?php echo $userimage ; ?>" alt="<?php echo $nameuser ; ?>" class="img-circle profile_img">
  </div>
  <div class="profile_info">
    <span>Welcome,</span>
    <h2><?php echo $nameuser ; ?></h2>
  </div>
</div>
