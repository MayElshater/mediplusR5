<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Manage <small><?php echo $title;?></small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                   <form action="searchuser.php" method="post"> 
                      <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search for..." name="query"> 
                          <span class="input-group-btn">
                             <button class="btn btn-secondary" type="submit">Go!</button> 
                          </span>
                       </div>
                   </form>
                  </div>
              </div>