<?php
include_once('conn.php');
try{
    $sql = "INSERT INTO `phone_index`( `name`, `phone`, `email`, `address`) VALUES (?,?,?,?)";
    if(isset($_POST['name'])){$name=$_POST['name'];}
    if(isset($_POST['phone'])){$phone=$_POST['phone'];}
    if(isset($_POST['email'])){$email=$_POST['email'];}
    if(isset($_POST['address'])){$address=$_POST['address'];}
    $stmt = $conn->prepare($sql);
    $stmt->execute([$name, $phone, $email, $address]);
    echo "Inserted";
} catch(PDOException $e) {
    echo $e->getMessage();
}
?>