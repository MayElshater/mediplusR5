<!DOCTYPE html>
<html lang="en">

<head>
    <?php
       $title="Contact";
       include_once("include/head.php");
    ?>
</head>

<body>
<?php
    include_once("include/topbar.php");
    include_once("include/navbar.php");
    include_once("include/search.php");
    include_once("include/pageheader.php");
    include_once("include/contact.php");
    include_once("include/vendor.php");
    include_once("include/footer.php");
    include_once("include/backtotop.php");
    include_once("include/footerjs.php");

    ?>
    

</body>

</html>